import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import userData from '../../datauser.json';
import { CustomerService } from '../customer-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  cus: Customer = new Customer();
  cust: Customer[] = [];
  username: string = '';
  upasswd: string = '';
  msg: string = '';
  datam: Customer[] = [];

  ngOnInit(): void {
    this.getcustomer();
  }

  getcustomer() {
    this.service.getCustomerList().subscribe((data) => {
      console.log('data', data);
      this.datam = data;
    });
    // this.service.getCustomerList().subscribe((data) => {
    //   this.datam = data;
    // });
  }
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CustomerService
  ) {
    this.service.getCustomerList().subscribe((response) => {
      this.cust = response;
    });
  }

  getValidation(tx1: any) {
    let un = this.username;
    let ps = this.upasswd;

    // this.service.getCustomerList().subscribe((data) => {
    //   userData = data;
    // });
    console.log('userdata', userData);
    var count = 0;
    var ud;
    let e: any;
    let userLoggedIn = false;
    // if (this.username == 'admin' && this.upasswd == 'admin') {
    //   sessionStorage.setItem('uname', un);
    //   console.log(sessionStorage.getItem('uname') + 'hello');
    //   console.log('xyz');
    //   console.log('usernamr', this.username);
    //   this.msg = `Successful login ${this.username} :)`;
    //   alert(this.msg);
    //   this.router.navigate(['/customer']);
    // } else {
    userData.map((e: { username: string; password: string }) => {
      if (this.username === e.username && this.upasswd === e.password) {
        userLoggedIn = true;
        localStorage.setItem('userName', e.username);
        this.router.navigate(['/customer']);
      } else {
        userLoggedIn = false;
      }
    });
    //   for (var i = 0; i < this.datam.length; i++) {
    //     if (
    //      this.datam[i].username == un &&
    //       this.datam[i].password == ps
    //     ) {
    //       ud=this.datam[i].id;
    //       console.log(ud+"sjdnn");
    //       count++;
    //       if (count == 1) {
    //         sessionStorage.setItem('uname',un);
    //         console.log(sessionStorage.getItem('uname')+"hello");
    //         console.log("xyz");
    //        this.msg = 'Successful login ' + this.username + ':)';
    //        alert("Successful")
    //         setTimeout(() => {
    //         //this.tinyAlert()
    //         this.router.navigate(['/customer']);
    //       });

    //       }else{
    //          alert("invalid user")
    //         }

    // }
    //   }
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/logout']);
  }
}
