import { Component, OnInit } from '@angular/core';
import userData from '../../datauser.json';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer-service.service';
import { Customer } from '../customer';
// import { constructor } from 'console';
// import  userss  from '../../app/customer/datauser.json';

interface Userdataa {
  id: Number;
  firstName: String;
  lastName: String;
  maidenName: String;
  age: Number;
  gender: String;
  email: String;
  phone: String;
  username: String;
  password: String;
  birthDate: String;
  image: String;
  bloodGroup: String;
  height: Number;
  weight: Number;
  hair: any;

  domain: String;
  ip: String;
  address: any;
  macAddress: String;
  university: String;
  company: any;
  bank: any;
  ssn: String;
  ein: String;
  userAgent: String;
}

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
})
export class CustomerComponent {
  lid: any;
  cust: Customer[] = [];
  username: string = '';
  cust1: Customer[] = [];
  upasswd: string = '';

  msg: string = '';
  datam: Customer[] = [];

  userDetails: Userdataa[] = userData;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CustomerService
  ) {
    let userName = localStorage.getItem('userName');
    userData.map((e) => {
      if (e.username === userName) {
        this.cust1.push(e);
      }
    });
    this.service.getCustomerList().subscribe((response) => {
      this.cust = response;
      this.datam = this.cust;
    });
  }

  // ngOnInit(): void {
  //   this.getcustomer();
  // }
  // getcustomer() {
  //   this.service.getCustomerList().subscribe((data) => {
  //     this.datam = data;
  //     console.log('datam', userData);
  //     this.lid = sessionStorage.getItem('uname');
  //     this.datam.map((e)=>{

  //     })
  //   });
  //   console.log('abc');
  // }
}
