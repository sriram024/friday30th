export class Customer {
        id!: number;
        firstName!: String;
        lastName!: String;
        maidenName!: String;
        age!: Number;
        gender!: String;
        email!: String;
        phone!: String;
        username!: String;
        password!: String;
        birthDate!: String;
        image!: String;
        bloodGroup!: String;
        height!: Number;
        weight!: Number;
        hair:any;
    
        domain!: String;
        ip!: String;
        address:any;
        macAddress!: String;
        university!: String;
        company:any;
        bank:any;
        ssn!: String;
        ein!: String;
        userAgent!: String;
      
      
      
      }