import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Customer } from './customer';

@Injectable({

  providedIn: 'root',

})

export class CustomerService {
  

  constructor(private http: HttpClient) {}

  url = '../datauser.json';

  getCustomerList() {

    return this.http.get<Customer[]>(this.url);

  }
  
  getOneData(id:any){
    return this.http.get<Customer[]>(this.url);

  }
}
